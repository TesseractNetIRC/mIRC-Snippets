go to http://www.gts-stuff.com
or #gtsdll @ irc.rizon.net
for help :P
#####################################
## Installation                    ##
#####################################
Extract the zip file to a directory of your choice, like C:\mIRC\gtsdll\

after that, type /load -rs <pathto gtsdll>\gtsdll.ini in any mirc window.

for example: /load -rs gtsdll\gtsdll.ini
or: /load -rs C:\mIRC\gtsdll\gtsdll.ini

Note: This addon need at least mirc 6.0 and the /dll and /run-command have to be unlocked.
To unlock this command press alt + o in mIRC, go to other/lock and uncheck "disable run, dll, com commands".

#####################################
## Uninstallation                  ##
#####################################
Type /unload -rs gtsdll.ini in a mirc-window.

After that you can delete the directory, you unzipped gtsdll to.
(make sure you don't have other important stuff in there ^^)

#####################################
## Notes about Azureus support     ##
#####################################
Please check out this link: 
http://www.gts-stuff.com/index.php/topic,1665.0.html

#####################################
## Notes about uTorrent support    ##
#####################################
Please check out this link: 
http://www.gts-stuff.com/index.php/topic,1676.html