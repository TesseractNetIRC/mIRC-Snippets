###########################################################
##							 ##
## Complete Guide To Having Foobar2000 Support in GTSdll ##
##							 ##
###########################################################

Requirements:

	- mIRC 6.17 or higher (only for unicode support).
	- GTSdll v1.2.7.0 Revision 3 and higher.
	- Foobar2000 v0.9.x And higher.
	- Foobar2000 COM Server Plugin by foosion, v0.7 Alpha 5 And Higher.
	  (Can be obtained at http://foosion.foobar2000.org/0.9/ and on HydrogenAudio.org)

Installing (Assuming you already installed mIRC and GTSdll):

	- Get and install the Foobar2000 COM Server Plugin as stated above.
	- Restart foobar to make sure the server has been registered.
	- In GTSdll, Make sure the line for selecting WinAmp's directory is blank.
	- It should now work just fine.

Known Issues:

	- The foobar plugin is path dependent, Meaning if you run foobar from an odd location,
	  The server plugin might not function properly. i.e. if foobar is running from places
	  like C:\Program Files\Foobar2000\Foobar2000.exe usualy, even the following path is
	  considered different: C:\PROGRA~1\FOOBAR~1\FOOBAR~1.EXE . I have encountered these
	  issues in things like launcher docks and keyboard hotkeys (esp. Zboard). If you're
	  having problems, make sure the path you're running from is the one that was
	  registered. To re-register the plugin in a new path, use Start -> Run, And type in
	  the new location followed by ' /regsvr:comserver2' without the quotes. i.e. ,
	  'C:\PROGRA~1\FOOBAR~1\FOOBAR~1.EXE /regsvr:comserver2' without the quotes. Note
	  that re-registering the server to a new path makes the old path invalid again.


	Enjoy the now playing support for the best audio player on windows :]

#####################################################################
## Written for: GTSdll v1.2.7.0 Revision 3		 	   ##
## By ChaosBlade.					 	   ##
## For Reporting Issues and Support, Visit #gtsdll @ irc.rizon.net ##
#####################################################################