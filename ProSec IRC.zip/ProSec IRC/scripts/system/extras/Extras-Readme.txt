This directory concains files that might be useful for some people.
NOTE: This file may be outdated, please check the documentation section on www.gts-stuff.com.

############################################################################
## foo_winamp_spam.0.9b3.dll                                              ##
############################################################################
## Version: 0.9b3                                                         ##
## Author: R1CH (aka Richard Stanway)                                     ##
## Webpage: http://www.r1ch.net/stuff/foobar/                             ##
############################################################################
Foobar2000 Plugin to emulate a Winamp window.
This enables GTSdll to support Foobar 2000.

Follow the directions as below, replacing the dll version with the 
appropriate one. Use 0.9b3 for Foobar 0.9 final and up.

How to Install:
Copy foo_winamp_spam.dll to your Foobar2000/components directory.
For example the location might be 
C:\Program Files\foobar2000\components\

Restart foobar2k, type /gtsdllsettings into a mIRC window
and make sure the field "Folder of Winamp(2.x/5)" is blank.
(It has to be blank, to work with foobar2k!)

Notes: GTSdll will still display WinAmp as player, since this foobar plugin
       emulates a WinAmp window. You may manually edit it in your theme ...
       Support for detailed file information will not work since GTSdll doesnt
       have direct access to the file.

############################################################################
## ABCConfig.exe                                                          ##
############################################################################
## Version: 1.0.5.0                                                       ##
## Author: GTS                                                            ##
## Webpage: http://www.adv-clan.com/gts-stuff/index.php?View=Downloads    ##
############################################################################
Configuration File Generator for ABC [Another BitTorrent Client].

If you use ABC and changed some columns with ABC-Tweak (ABC Options) you
have to use this tool to generate a new Configuration-File for GTSdll. 
Because GTSdll might display weird stuff or may even Crash mIRC...

Using this little program is self-explanatory. Just execute it, 
and see for yourself.


############################################################################
## �TorrentCONFIG.exe                                                     ##
############################################################################
## Version: 1.0.4.0							  ##
## Author: Chaosblade                                                     ##
## Webpage: http://www.adv-clan.com/gts-stuff/index.php?View=Downloads    ##
############################################################################
Configuration File Generator for �Torrent.

If you use �Torrent you have to use this tool to generate a new 
Configuration-File for GTSdll. Otherwise, GTSDLL will be unable to 
communicate with �Torrent. If you change any columns, you may need to make
a new config.

Using this little program is self-explanatory. Just execute it, 
and see for yourself.


############################################################################
## utcfg.exe                                                     	  ##
############################################################################
## Version: 1.0.4.0							  ##
## Author: Chaosblade                                                     ##
## Webpage: http://www.adv-clan.com/gts-stuff/index.php?View=Downloads    ##
############################################################################
Console-based configuration File Generator for �Torrent.

If you use �Torrent you have to use this tool to generate a new 
Configuration-File for GTSdll. Otherwise, GTSDLL will be unable to 
communicate with �Torrent. If you change any columns, you may need to make
a new config.

No documentation currently exists for this program.

