For help with configuring Azureus to work with GTSDLL, please take a look at
http://www.gts-stuff.com/index.php/topic,1665.0.html