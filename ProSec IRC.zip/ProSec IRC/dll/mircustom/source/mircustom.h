// return values
#define MRV_HALT			0
#define MRV_CONTINUE	1
#define MRV_PERFORM		2
#define MRV_RETURN		3

// general constants & macros
#define MIRCDECLARE		extern "C" int __stdcall
#define MIRCPARAMS		HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause
#define RetOK					{ lstrcpy(data, "S_OK"); return MRV_RETURN; }
#define RetErr(Err)		{ lstrcpy(data, "E_" ERR_ ## Err); return MRV_RETURN; }

// error messages
#define ERR_INVPARAM	"INVPARAM invalid parameters"
#define ERR_FNF				"NOTFOUND file not found"
#define ERR_BIGPATH		"BIGPATH file path is too big"
#define ERR_NOICON		"INVICON icon not found"
#define ERR_INVHWND		"INVHWND invalid window"
#define ERR_SYSERR		"SYSERR system error; unknown problem happened"

// DllInfo constants
#define DLLVERSION  "1.3"
#define DLLINFO     "mIRCustom " DLLVERSION " for mIRC 5.8+ � 2001-2002 Kamek - ircweb@hotmail.com"



// Structures
typedef struct {
  DWORD  mVersion;
  HWND   mHwnd;
  BOOL   mKeep;
} LOADINFO;

// Global variables
HINSTANCE hInstance;
