/**project info**
* target: Windows/DLL
* author: Kamek
* name: mircustom
* description: mIRC customizer
*/
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
// including shellapi.h here because the WIN32_LEAN_AND_MEAN prevents
// windows.h from including it naturally
#include <shellapi.h>
#include "mircustom.h"

extern "C" int WINAPI _DllMainCRTStartup(HANDLE hInstDLL, DWORD, void*) {
	hInstance = (HINSTANCE)hInstDLL;
	return 1;
}

/*
	IsNumTok will check if the first token of the specified string is a
	number. If so, it will copy the numeric value to the variable pointed
	by the 'n' parameter, will change the position of the pointer sent to
	the first parameter to the next token, and return TRUE.

	Note that it will only return TRUE if the number is valid and if
	there's at least one more parameter following the first one.
*/
BOOL IsNumTok(char **str, char chr, UINT *n) {
	*n = 0;
	for (char *p = *str; *p; p++) {
		if ((*p >= '0') && (*p <= '9'))
			*n = *n * 10 + *p - '0';
		else if ((*p == chr) && (p > *str)) {
			*str = &p[1];
			return TRUE;
		}
		else break;
	}
	return FALSE;
}

HWND GetTargetWindow(char* data, HWND aWnd, HWND mWnd) {
	if (lstrlen(data) <= 3) return NULL;
	if ((data[0] == '-') && (data[2] == ' '))
		switch (data[1]) {
			case 'm':
				lstrcpy(data, &data[3]);
				return mWnd;
			case 'a':
				lstrcpy(data, &data[3]);
				return aWnd;
			case 'w':
			{
				HWND hWnd;
				char *newdata = &data[3];

				if (IsNumTok(&newdata, ' ', (UINT*)&hWnd)) {
					lstrcpy(data, newdata);
					return IsWindow(hWnd)? hWnd : NULL;
				}
			}
		}
	return NULL;
}



extern "C" void __stdcall LoadDll(LOADINFO* lInfo) {
	// keep the DLL in memory to speed up requests
	lInfo->mKeep = TRUE;
}

/*****
	Titlebar -amw <text>
		-a   - active window
		-m   - mIRC main window
		-w <hWnd> - another window
			use $window().hwnd or $dialog().hwnd for the hWnd part
		text - the text you want for the titlebar
*****/
MIRCDECLARE Titlebar(MIRCPARAMS) {
	HWND hWnd = GetTargetWindow(data, aWnd, mWnd);

	if (!hWnd) RetErr(INVHWND)
	SetWindowText(hWnd, data);
	RetOK
}

/*****
	SetIcon -amw [index] <filename>
		The switches are the same as in Titlebar
		index    - icon index (starting from 1)
		filename - self-explanatory

	If you don't specify an index, 1 will be used.
*****/
MIRCDECLARE SetIcon(MIRCPARAMS) {
	HICON LargeIcon, SmallIcon;
	UINT Index;
	DWORD Result;
	char *FileName = data, FullName[MAX_PATH];
	HWND hWnd = GetTargetWindow(data, aWnd, mWnd);

	if (!hWnd) RetErr(INVHWND)
	if (!IsNumTok(&FileName, ' ', &Index))
		Index = 0;
	else if (Index > 0) Index--;

	// look for the file in default paths...
	Result = SearchPath(NULL, FileName, NULL, sizeof(FullName), FullName, NULL);
	if (Result == 0) RetErr(FNF)
	if (Result > sizeof(FullName)) RetErr(BIGPATH)
	if (ExtractIconEx(FullName, Index, &LargeIcon, &SmallIcon, 1) == 0) RetErr(NOICON)

	// try to have both icons
	if (!LargeIcon) LargeIcon = SmallIcon;
	else if (!SmallIcon) SmallIcon = LargeIcon;

	SmallIcon = (HICON)SendMessage(hWnd, WM_SETICON, ICON_SMALL, (LPARAM)SmallIcon);
	LargeIcon = (HICON)SendMessage(hWnd, WM_SETICON, ICON_BIG, (LPARAM)LargeIcon);
	if (SmallIcon) DestroyIcon(SmallIcon);
	if (LargeIcon) DestroyIcon(LargeIcon);
	RetOK
}

/*****
	CountIcons <filename>

	Returns the number of icons the file has
*****/
MIRCDECLARE CountIcons(MIRCPARAMS) {
	char FullName[MAX_PATH];
	DWORD Result;

	Result = SearchPath(NULL, data, NULL, sizeof(FullName), FullName, NULL);
	if (Result == 0) RetErr(FNF)
	if (Result > sizeof(FullName)) RetErr(BIGPATH)
	wsprintf(data, "S_OK %u", ExtractIconEx(FullName, -1, NULL, NULL, 1));
	return MRV_RETURN;
}

/*****
	SetCursor -amw <cursor>
		The switches are the same as in Titlebar
		cursor - one of the following:
			default      ibeam     sizenwse
			appstarting  no        sizewe
			cross        size      uparrow
			hand         sizenesw  wait
			help         sizens

	Note that since there's already a function named "SetCursor" in the Windows
	API, we have name this one internally with something different, but the .def
	file exports it with the SetCursor name.
*****/
MIRCDECLARE mSetCursor(MIRCPARAMS) {
	const char Cursors[][12] = {"default", "appstarting", "cross", "hand", "help",
		"ibeam", "no", "size", "sizenesw", "sizens", "sizenwse", "sizewe",
		"uparrow", "wait"};
	const LPTSTR Values[] = {IDC_ARROW, IDC_APPSTARTING, IDC_CROSS, IDC_HAND, IDC_HELP,
		IDC_IBEAM, IDC_NO, IDC_SIZEALL, IDC_SIZENESW, IDC_SIZENS, IDC_SIZENWSE, IDC_SIZEWE,
		IDC_UPARROW, IDC_WAIT};

	UINT i;
	HCURSOR hCurNew;
	HWND hWnd = GetTargetWindow(data, aWnd, mWnd);

	if (!hWnd) RetErr(INVHWND)
	for (i = 0; i < sizeof(Cursors) / sizeof(Cursors[0]); i++)
		if (!lstrcmpi(Cursors[i], data)) {
			hCurNew = LoadCursor(NULL, Values[i]);
			if (!hCurNew) RetErr(SYSERR)
			SetClassLongPtr(hWnd, GCL_HCURSOR, (LONG_PTR)hCurNew);
			RetOK
		}
	RetErr(INVPARAM)
}

#if 0
/*****
	GetOSVersion

	(disabled as it doesn't seem to be useful for most users)
*****/
MIRCDECLARE GetOSVersion(MIRCPARAMS) {
	OSVERSIONINFO VersionInfo; char WinVer[5];
	VersionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx(&VersionInfo);
	switch (VersionInfo.dwPlatformId) {
		case VER_PLATFORM_WIN32s:
			lstrcpy(WinVer, "32s");
			break;
		case VER_PLATFORM_WIN32_WINDOWS:
			if (VersionInfo.dwMinorVersion > 0) {
				if (VersionInfo.dwMinorVersion >= 90)
					lstrcpy(WinVer, "Me");
				else if ((VersionInfo.dwMinorVersion >= 10) && (VersionInfo.dwBuildNumber >= 2222)) 
					lstrcpy(WinVer, "98SE");
				else
					lstrcpy(WinVer, "98");
			}
			else
				lstrcpy(WinVer, "95");
			break;
		case VER_PLATFORM_WIN32_NT:
			if (VersionInfo.dwMajorVersion >= 5)
				lstrcpy(WinVer, (VersionInfo.dwMinorVersion >= 1)? "XP" : "2000");
			else
				lstrcpy(WinVer, "NT");
			break;
	}
	wsprintf(data, "S_OK Windows %s %lu.%02lu.%04u%s", WinVer, VersionInfo.dwMajorVersion, VersionInfo.dwMinorVersion,
		LOWORD(VersionInfo.dwBuildNumber), VersionInfo.szCSDVersion);
	return MRV_RETURN;
}
#endif

/*****
	DLLInfo
*****/
MIRCDECLARE DLLInfo(MIRCPARAMS) {
	lstrcpy(data, "S_OK " DLLINFO);
	return MRV_RETURN;
}
